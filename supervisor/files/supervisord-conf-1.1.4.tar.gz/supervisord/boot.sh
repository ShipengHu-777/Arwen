#!/bin/bash


/usr/bin/supervisord -c /data/projects/common/supervisord/supervisord.conf

 
