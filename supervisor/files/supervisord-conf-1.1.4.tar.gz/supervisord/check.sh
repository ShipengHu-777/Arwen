#!bin/bash

base="/data/projects/common/supervisord"
key="/data/projects/common/supervisord/supervisord.conf"
ps aux|grep $key 
num=$(ps aux|grep -c $key)
if [ $num -le 2 ]
then
  echo "supervisord not up, booting($num)"
  nohup /bin/bash $base/boot.sh > $base/logs/boot.log 2>&1 &
else
  echo "supervisord has been up($num)"
fi
